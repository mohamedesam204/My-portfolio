﻿using BankSystemBackend.Enums;
using Microsoft.AspNetCore.Identity;

namespace BankSystemBackend.Models
{
    public class AppUser : IdentityUser
    {
        public string? PhotoUrl { get; set; }

        public UserRole Role { get; set; }
    }
}