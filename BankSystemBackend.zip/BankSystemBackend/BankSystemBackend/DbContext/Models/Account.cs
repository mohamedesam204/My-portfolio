using BankSystemBackend.Enums;

namespace BankSystemBackend.Models
{
    public class Account
    {
        public int Id { get; set; }

        public decimal Balance { get; set; }

        public AccountType AccountType { get; set; }

        public AccountStatus AccountStatus { get; set; }

        public ICollection<Transactions> Transactions { get; set; }

        public Customer Customer { get; set; }

        public string? CustomerId { get; set; }
    }
}
