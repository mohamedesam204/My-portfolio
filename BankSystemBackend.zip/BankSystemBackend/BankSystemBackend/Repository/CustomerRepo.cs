using BankSystemBackend.Dto.AccountDTO;
using BankSystemBackend.Dto.CustomerDTO;
using BankSystemBackend.Dto.LoanDTO;
using BankSystemBackend.Enums;
using BankSystemBackend.IRepository;
using BankSystemBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace BankSystemBackend.Repository
{
    public class CustomerRepo : ICustomerRepo
    {
        private readonly AppDbContext _context;
        private readonly Microsoft.AspNetCore.Identity.UserManager<AppUser> _userManager;

        public CustomerRepo(AppDbContext context, Microsoft.AspNetCore.Identity.UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<TransactionResponseDto> TransferAsync(TransactionDto dto)
        {
            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var sourceAccount = await _context.Set<Account>().FindAsync(dto.AccountId)
                    ?? throw new KeyNotFoundException($"Account {dto.AccountId} not found.");
                var targetAccount = await _context.Set<Account>().FindAsync(dto.TargetAccountId)
                    ?? throw new KeyNotFoundException($"Target account {dto.TargetAccountId} not found.");
                if (sourceAccount.Balance < dto.Amount)
                    throw new InvalidOperationException("Insufficient balance.");
                sourceAccount.Balance -= dto.Amount;
                targetAccount.Balance += dto.Amount;
                var bankTransaction = new Transactions
                {
                    Date = DateTime.UtcNow,
                    Amount = dto.Amount,
                    Message = dto.Message,
                    Type = TransactionType.Transfer,
                    Status = TransactionStatus.Completed,
                    AccountFK = dto.AccountId,
                    TargetAccountFK = dto.TargetAccountId
                };
                _context.Transactions.Add(bankTransaction);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return MapTransaction(bankTransaction, dto.AccountId);
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<List<TransactionResponseDto>> GetAllTransactionsAsync(int accountId, int page = 1, int pageSize = 10)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 10;
            return await _context.Transactions
                .Where(t => t.AccountFK == accountId)
                .OrderByDescending(t => t.Date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(t => MapTransaction(t, accountId))
                .ToListAsync();
        }

        public async Task<DisplayCustomer?> GetProfileAsync(string customerId)
        {
            var c = await _context.Customers.FindAsync(customerId);
            return c is null ? null : MapCustomer(c);
        }

        public async Task<DisplayCustomer> UpdateProfileAsync(string customerId, EditCustomer dto)
        {
            var customer = await _context.Customers.FindAsync(customerId)
                ?? throw new KeyNotFoundException($"Customer {customerId} not found.");
            customer.UserName = dto.Name;
            customer.Email = dto.Email;
            customer.PhotoUrl = dto.PhotoUrl;
            customer.PhoneNumber = dto.PhoneNumber;
            customer.City = dto.City;
            customer.Street = dto.Street;
            customer.State = dto.State;
            customer.PostalCode = dto.PostalCode;
            if (!string.IsNullOrWhiteSpace(dto.Password))
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(customer);
                var result = await _userManager.ResetPasswordAsync(customer, token, dto.Password);
                if (!result.Succeeded)
                    throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));
            }
            await _context.SaveChangesAsync();
            return MapCustomer(customer);
        }

        public async Task<Microsoft.AspNetCore.Identity.IdentityResult> ChangePasswordAsync(string customerId, ChangePasswordDto dto)
        {
            var customer = await _userManager.FindByIdAsync(customerId);
            if (customer is null) return Microsoft.AspNetCore.Identity.IdentityResult.Failed(new Microsoft.AspNetCore.Identity.IdentityError { Description = "User not found" });
            return await _userManager.ChangePasswordAsync(customer, dto.CurrentPassword, dto.NewPassword);
        }

        public async Task<List<DisplayAccount>> GetMyAccountsAsync(string customerId, int page = 1, int pageSize = 10)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 10;
            return await _context.Set<Account>()
                .Where(a => a.CustomerId == customerId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(a => new DisplayAccount
                {
                    Id = a.Id,
                    CustomerId = a.CustomerId,
                    AccountType = a.AccountType,
                    Balance = a.Balance
                })
                .ToListAsync();
        }

        public async Task<bool> OwnsAccountAsync(string customerId, int accountId)
        {
            return await _context.Set<Account>()
                .AnyAsync(a => a.Id == accountId && a.CustomerId == customerId);
        }

        public async Task<decimal> GetAccountBalanceAsync(int accountId)
        {
            var account = await _context.Set<Account>().FindAsync(accountId)
                ?? throw new KeyNotFoundException($"Account {accountId} not found.");
            return account.Balance;
        }

        public async Task<List<DisplayLoans>> GetMyLoansAsync(string customerId)
        {
            return await _context.Loans
                .Where(l => l.CustomerId == customerId)
                .Select(l => MapLoan(l))
                .ToListAsync();
        }

        public async Task<DisplayLoans?> GetLoanByIdAsync(int loanId)
        {
            var loan = await _context.Loans.FindAsync(loanId);
            return loan is null ? null : MapLoan(loan);
        }

        private static DisplayCustomer MapCustomer(Customer c) => new()
        {
            Id = c.Id, Name = c.UserName, Email = c.Email, PhotoUrl = c.PhotoUrl,
            PhoneNumber = c.PhoneNumber, City = c.City, Street = c.Street,
            State = c.State, PostalCode = c.PostalCode
        };

        private static DisplayLoans MapLoan(Loan l) => new()
        {
            Id = l.Id, OriginalAmount = (decimal)l.OriginalAmount,
            Amount = (decimal)l.RemainingAmount, InterestRate = (decimal)l.InterestRate,
            DurationMonths = l.DurationMonths, StartDate = l.StartDate,
            Status = l.Status, CustomerId = l.CustomerId ?? string.Empty
        };

        private static TransactionResponseDto MapTransaction(Transactions t, int accountId) => new()
        {
            AccountId = accountId, Amount = t.Amount, Message = t.Message,
            Type = t.Type, Date = t.Date, TargetAccountId = t.TargetAccountFK
        };
    }
}
