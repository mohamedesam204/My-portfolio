using BankSystemBackend.Dto.BranchDto;
using BankSystemBackend.Dto.CustomerDTO;
using BankSystemBackend.Dto.TellerDTO;
using BankSystemBackend.IRepository;
using BankSystemBackend.Models;
using Microsoft.EntityFrameworkCore;

namespace BankSystemBackend.Repository
{
    public class AdminRepo : IAdminRepo
    {
        private readonly AppDbContext _context;
        private readonly Microsoft.AspNetCore.Identity.UserManager<AppUser> _userManager;

        public AdminRepo(AppDbContext context, Microsoft.AspNetCore.Identity.UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // --- Customer reads -------------------------------------------

        public async Task<List<DisplayCustomer>> GetAllCustomersAsync(int page = 1, int pageSize = 10)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 10;
            return await _context.Customers
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(c => MapCustomer(c))
                .ToListAsync();
        }

        public async Task<DisplayCustomer?> GetCustomerByIdAsync(string id)
        {
            var c = await _context.Customers.FindAsync(id);
            return c is null ? null : MapCustomer(c);
        }

        public async Task<int> GetCustomerCountAsync()
        {
            return await _context.Customers.CountAsync();
        }

        // --- Customer write -------------------------------------------
        public async Task<BankSystemBackend.Dto.AccountDTO.DisplayAccount> AddAccountAsync(string customerId, BankSystemBackend.Dto.AccountDTO.CreateAccount dto)
        {
            var customer = await _context.Customers.FindAsync(customerId)
                ?? throw new KeyNotFoundException($"Customer {customerId} not found.");

            var account = new Account
            {
                CustomerId = customerId,
                AccountType = dto.AccountType,
                Balance = 0,
                AccountStatus = Enums.AccountStatus.Active
            };

            _context.Set<Account>().Add(account);
            await _context.SaveChangesAsync();

            return new BankSystemBackend.Dto.AccountDTO.DisplayAccount
            {
                Id = account.Id,
                CustomerId = account.CustomerId,
                AccountType = account.AccountType,
                Balance = account.Balance
            };
        }

        public async Task<DisplayCustomer> AddCustomerAsync(AddCustomer dto)
        {
            var customer = new Customer
            {
                UserName = dto.Name,
                Email = dto.Email,
                PhotoUrl = dto.PhotoUrl,
                PhoneNumber = dto.PhoneNumber,
                City = dto.City,
                Street = dto.Street,
                State = dto.State,
                PostalCode = dto.PostalCode,
                Role = Enums.UserRole.Customer
            };

            var result = await _userManager.CreateAsync(customer, dto.Password);
            if (!result.Succeeded) throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));
            await _userManager.AddToRoleAsync(customer, "Customer");

            return MapCustomer(customer);
        }

        public async Task<DisplayCustomer> UpdateCustomerAsync(string id, EditCustomer dto)
        {
            var customer = await _context.Customers.FindAsync(id)
                ?? throw new KeyNotFoundException($"Customer {id} not found.");

            customer.UserName = dto.Name;
            customer.Email = dto.Email;
            customer.PhotoUrl = dto.PhotoUrl;
            customer.PhoneNumber = dto.PhoneNumber;
            customer.City = dto.City;
            customer.Street = dto.Street;
            customer.State = dto.State;
            customer.PostalCode = dto.PostalCode;

            if (!string.IsNullOrWhiteSpace(dto.Password))
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(customer);
                var result = await _userManager.ResetPasswordAsync(customer, token, dto.Password);
                if (!result.Succeeded)
                    throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));
            }

            await _context.SaveChangesAsync();
            return MapCustomer(customer);
        }

        public async Task<bool> DeleteCustomerAsync(string id)
        {
            var customer = await _userManager.FindByIdAsync(id);
            if (customer is null) return false;
            var result = await _userManager.DeleteAsync(customer);
            return result.Succeeded;
        }

        // --- Aggregate statistics -------------------------------------

        public async Task<decimal> GetTotalDepositsAsync()
        {
            return await _context.Transactions
                .Where(t => t.Type == Enums.TransactionType.Deposit
                         && t.Status == Enums.TransactionStatus.Completed)
                .SumAsync(t => t.Amount);
        }

        public async Task<decimal> GetTotalLoansAsync()
        {
            return await _context.Loans
                .Where(l => l.Status == Enums.LoanStatus.Approved)
                .SumAsync(l => (decimal)l.OriginalAmount);
        }

        public async Task<decimal> TotalAmountAsync()
        {
            return await _context.Customers
                .Include(c => c.Accounts)
                .SelectMany(c => c.Accounts)
                .SumAsync(a => a.Balance);
        }

        public async Task<decimal> GetTotalFeesAsync()
        {

            var totalTransfers = await _context.Transactions
                .Where(t => t.Type == Enums.TransactionType.Transfer
                         && t.Status == Enums.TransactionStatus.Completed)
                .SumAsync(t => t.Amount);

            return totalTransfers * 0.01m;
        }

        public async Task<decimal> TotalWithdrawalsAsync()
        {
            return await _context.Transactions
                .Where(t => t.Type == Enums.TransactionType.Withdraw
                         && t.Status == Enums.TransactionStatus.Completed)
                .SumAsync(t => t.Amount);
        }

        // --- Teller CRUD ----------------------------------------------

        public async Task<DisplayTeller?> GetTellerByIdAsync(string id)
        {
            var t = await _context.Tellers.FindAsync(id);
            return t is null ? null : MapTeller(t);
        }

        public async Task<List<DisplayTeller>> GetAllTellersAsync(int page = 1, int pageSize = 10)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 10;
            return await _context.Tellers
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(t => MapTeller(t))
                .ToListAsync();
        }

        public async Task<int> GetTellerCountAsync()
        {
            return await _context.Tellers.CountAsync();
        }

        public async Task<DisplayTeller> AddTellerAsync(AddTeller dto)
        {
            var teller = new Teller
            {
                UserName = dto.Name,
                Email = dto.Email,
                PhotoUrl = dto.PhotoUrl,
                PhoneNumber = dto.PhoneNumber,
                BranchFK = dto.BranchFK,
                Role = Enums.UserRole.Teller
            };

            var result = await _userManager.CreateAsync(teller, dto.Password);
            if (!result.Succeeded) throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));
            await _userManager.AddToRoleAsync(teller, "Teller");

            return MapTeller(teller);
        }

        public async Task<DisplayTeller> UpdateTellerAsync(string id, EditTeller dto)
        {
            var teller = await _context.Tellers.FindAsync(id)
                ?? throw new KeyNotFoundException($"Teller {id} not found.");

            teller.UserName = dto.Name;
            teller.Email = dto.Email;
            teller.PhotoUrl = dto.PhotoUrl;
            teller.BranchFK = dto.BranchFK;

            if (!string.IsNullOrWhiteSpace(dto.Password))
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(teller);
                var result = await _userManager.ResetPasswordAsync(teller, token, dto.Password);
                if (!result.Succeeded)
                    throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));
            }

            await _context.SaveChangesAsync();
            return MapTeller(teller);
        }

        public async Task<bool> DeleteTellerAsync(string id)
        {
            var teller = await _userManager.FindByIdAsync(id);
            if (teller is null) return false;
            var result = await _userManager.DeleteAsync(teller);
            return result.Succeeded;
        }

        // --- Branch CRUD ----------------------------------------------

        public async Task<DisplayBranch> AddBranchAsync(AddBranch dto)
        {
            var branch = new Branch
            {
                Name = dto.Name,
                Location = dto.Address
            };

            _context.Branches.Add(branch);
            await _context.SaveChangesAsync();

            return new DisplayBranch { Id = branch.Id, Name = branch.Name, Address = branch.Location };
        }

        public async Task<DisplayBranch> UpdateBranchAsync(int id, EditBranch dto)
        {
            var branch = await _context.Branches.FindAsync(id)
                ?? throw new KeyNotFoundException($"Branch {id} not found.");

            branch.Name = dto.Name;
            branch.Location = dto.Address;

            await _context.SaveChangesAsync();
            return new DisplayBranch { Id = branch.Id, Name = branch.Name, Address = branch.Location };
        }

        public async Task<bool> DeleteBranchAsync(int id)
        {
            var branch = await _context.Branches.FindAsync(id);
            if (branch is null) return false;

            _context.Branches.Remove(branch);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<DisplayBranch>> GetAllBranchesAsync()
        {
            return await _context.Branches
                .Select(b => new DisplayBranch { Id = b.Id, Name = b.Name, Address = b.Location })
                .ToListAsync();
        }

        public async Task<DisplayBranch?> GetBranchByIdAsync(int id)
        {
            var b = await _context.Branches.FindAsync(id);
            return b is null ? null : new DisplayBranch { Id = b.Id, Name = b.Name, Address = b.Location };
        }

        public async Task<int> GetBranchCountAsync()
        {
            return await _context.Branches.CountAsync();
        }

        // --- Mapping helpers ------------------------------------------

        private static DisplayCustomer MapCustomer(Customer c) => new()
        {
            Id = c.Id,
            Name = c.UserName,
            Email = c.Email,
            PhotoUrl = c.PhotoUrl,
            PhoneNumber = c.PhoneNumber,
            City = c.City,
            Street = c.Street,
            State = c.State,
            PostalCode = c.PostalCode
        };

        private static DisplayTeller MapTeller(Teller t) => new()
        {
            Id = t.Id,
            Name = t.UserName,
            Email = t.Email,
            PhotoUrl = t.PhotoUrl,
            BranchFK = t.BranchFK
        };
    }
}


