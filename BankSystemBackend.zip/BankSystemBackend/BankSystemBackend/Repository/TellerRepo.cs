using BankSystemBackend.Dto.AccountDTO;
using BankSystemBackend.Dto.CustomerDTO;
using BankSystemBackend.Dto.LoanDTO;
using BankSystemBackend.Enums;
using BankSystemBackend.IRepository;
using BankSystemBackend.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace BankSystemBackend.Repository
{
    public class TellerRepo : ITellerRepo
    {
        private readonly AppDbContext _context;

        public TellerRepo(AppDbContext context)
        {
            _context = context;
        }

        // --- Transactions ---------------------------------------------

        public async Task<TransactionResponseDto> DepositAsync(int accountId, decimal amount, string message = "")
        {
            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var account = await _context.Set<Account>().FindAsync(accountId)
                    ?? throw new KeyNotFoundException($"Account {accountId} not found.");
                account.Balance += amount;
                var bankTransaction = new Transactions
                {
                    Date = DateTime.UtcNow, Amount = amount, Message = message,
                    Type = TransactionType.Deposit, Status = TransactionStatus.Completed,
                    AccountFK = accountId
                };
                _context.Transactions.Add(bankTransaction);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return MapTransaction(bankTransaction, accountId);
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<TransactionResponseDto> WithdrawAsync(int accountId, decimal amount, string message = "")
        {
            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var account = await _context.Set<Account>().FindAsync(accountId)
                    ?? throw new KeyNotFoundException($"Account {accountId} not found.");
                if (account.Balance < amount)
                    throw new InvalidOperationException("Insufficient balance.");
                account.Balance -= amount;
                var bankTransaction = new Transactions
                {
                    Date = DateTime.UtcNow, Amount = amount, Message = message,
                    Type = TransactionType.Withdraw, Status = TransactionStatus.Completed,
                    AccountFK = accountId
                };
                _context.Transactions.Add(bankTransaction);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return MapTransaction(bankTransaction, accountId);
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<TransactionResponseDto> TransferAsync(TransactionDto dto)
        {
            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var source = await _context.Set<Account>().FindAsync(dto.AccountId)
                    ?? throw new KeyNotFoundException($"Account {dto.AccountId} not found.");
                var target = await _context.Set<Account>().FindAsync(dto.TargetAccountId)
                    ?? throw new KeyNotFoundException($"Target account {dto.TargetAccountId} not found.");
                if (source.Balance < dto.Amount)
                    throw new InvalidOperationException("Insufficient balance.");
                source.Balance -= dto.Amount;
                target.Balance += dto.Amount;
                var bankTransaction = new Transactions
                {
                    Date = DateTime.UtcNow, Amount = dto.Amount, Message = dto.Message,
                    Type = TransactionType.Transfer, Status = TransactionStatus.Completed,
                    AccountFK = dto.AccountId, TargetAccountFK = dto.TargetAccountId
                };
                _context.Transactions.Add(bankTransaction);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                return MapTransaction(bankTransaction, dto.AccountId, dto.TargetAccountId);
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task<List<TransactionResponseDto>> GetTransactionHistoryAsync(int accountId, int page = 1, int pageSize = 10)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 10;
            return await _context.Transactions
                .Where(t => t.AccountFK == accountId)
                .OrderByDescending(t => t.Date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(t => MapTransaction(t, accountId))
                .ToListAsync();
        }

        public async Task<TransactionResponseDto?> GetTransactionByIdAsync(int transactionId)
        {
            var t = await _context.Transactions.FindAsync(transactionId);
            return t is null ? null : MapTransaction(t, t.AccountFK ?? 0);
        }

        // --- Accounts -------------------------------------------------

        public async Task<DisplayAccount?> GetAccountByIdAsync(int accountId)
        {
            var a = await _context.Set<Account>().FindAsync(accountId);
            return a is null ? null : MapAccount(a);
        }

        public async Task<List<DisplayAccount>> GetCustomerAccountsAsync(string customerId, int page = 1, int pageSize = 10)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 10;
            return await _context.Set<Account>()
                .Where(a => a.CustomerId == customerId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(a => MapAccount(a))
                .ToListAsync();
        }

        public async Task<decimal> GetAccountBalanceAsync(int accountId)
        {
            var account = await _context.Set<Account>().FindAsync(accountId)
                ?? throw new KeyNotFoundException($"Account {accountId} not found.");
            return account.Balance;
        }

        // --- Customer & Loans -----------------------------------------

        public async Task<DisplayLoans> AddLoansAsync(string customerId, AddLoan dto)
        {
            var customer = await _context.Customers.FindAsync(customerId)
                ?? throw new KeyNotFoundException($"Customer {customerId} not found.");
            var loan = new Loan
            {
                OriginalAmount = (double)dto.OriginalAmount,
                RemainingAmount = (double)dto.OriginalAmount,
                InterestRate = (double)dto.InterestRate,
                DurationMonths = dto.DurationMonths,
                Purpose = dto.Purpose,
                Status = dto.Status,
                StartDate = dto.StartDate,
                CustomerId = customerId
            };
            _context.Loans.Add(loan);
            await _context.SaveChangesAsync();
            return new DisplayLoans
            {
                Id = loan.Id,
                OriginalAmount = (decimal)loan.OriginalAmount,
                Amount = (decimal)loan.RemainingAmount,
                InterestRate = (decimal)loan.InterestRate,
                DurationMonths = loan.DurationMonths,
                StartDate = loan.StartDate,
                Status = loan.Status,
                CustomerId = loan.CustomerId
            };
        }

        public async Task<DisplayCustomer?> GetCustomerByIdAsync(string customerId)
        {
            var c = await _context.Customers.FindAsync(customerId);
            return c is null ? null : MapCustomer(c);
        }

        public async Task<List<DisplayLoans>> GetCustomerLoansAsync(string customerId)
        {
            return await _context.Loans
                .Where(l => l.CustomerId == customerId)
                .Select(l => new DisplayLoans
                {
                    Id = l.Id,
                    OriginalAmount = (decimal)l.OriginalAmount,
                    Amount = (decimal)l.RemainingAmount,
                    InterestRate = (decimal)l.InterestRate,
                    DurationMonths = l.DurationMonths,
                    StartDate = l.StartDate,
                    Status = l.Status,
                    CustomerId = l.CustomerId
                })
                .ToListAsync();
        }

        // --- Mapping helpers ------------------------------------------

        private static DisplayCustomer MapCustomer(Customer c) => new()
        {
            Id = c.Id, Name = c.UserName, Email = c.Email, PhotoUrl = c.PhotoUrl,
            PhoneNumber = c.PhoneNumber, City = c.City, Street = c.Street,
            State = c.State, PostalCode = c.PostalCode
        };

        private static DisplayAccount MapAccount(Account a) => new()
        {
            Id = a.Id, CustomerId = a.CustomerId,
            AccountType = a.AccountType, Balance = a.Balance
        };

        private static TransactionResponseDto MapTransaction(
            Transactions t, int accountId, int? targetAccountId = null) => new()
            {
                AccountId = accountId, Amount = t.Amount, Message = t.Message,
                Type = t.Type, Date = t.Date, TargetAccountId = targetAccountId
            };
    }
}
