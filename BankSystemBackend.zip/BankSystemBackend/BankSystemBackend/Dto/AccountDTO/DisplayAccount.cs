﻿using BankSystemBackend.Enums;

namespace BankSystemBackend.Dto.AccountDTO
{
    public class DisplayAccount
    {
        public string? CustomerId { get; set; }
        public AccountType AccountType { get; set; }
        public int Id { get; set; }
        public decimal Balance { get; set; }

    }
}
