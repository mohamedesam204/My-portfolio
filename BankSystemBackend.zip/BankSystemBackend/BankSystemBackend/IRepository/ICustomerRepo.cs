using BankSystemBackend.Dto.AccountDTO;
using BankSystemBackend.Dto.CustomerDTO;
using BankSystemBackend.Dto.LoanDTO;

namespace BankSystemBackend.IRepository
{
    public interface ICustomerRepo
    {
        // --- Transactions ---------------------------------------------
        Task<TransactionResponseDto> TransferAsync(TransactionDto dto);

        Task<List<TransactionResponseDto>> GetAllTransactionsAsync(int accountId, int page = 1, int pageSize = 10);

        // --- Profile --------------------------------------------------
        Task<DisplayCustomer?> GetProfileAsync(string customerId);

        Task<DisplayCustomer> UpdateProfileAsync(string customerId, EditCustomer Profile);

        Task<Microsoft.AspNetCore.Identity.IdentityResult> ChangePasswordAsync(string customerId, BankSystemBackend.Dto.CustomerDTO.ChangePasswordDto dto);

        // --- Accounts -------------------------------------------------
        Task<List<DisplayAccount>> GetMyAccountsAsync(string customerId, int page = 1, int pageSize = 10);

        Task<bool> OwnsAccountAsync(string customerId, int accountId);

        Task<decimal> GetAccountBalanceAsync(int accountId);

        // --- Loans ----------------------------------------------------
        Task<List<DisplayLoans>> GetMyLoansAsync(string customerId);

        Task<DisplayLoans?> GetLoanByIdAsync(int loanId);
    }
}


