using BankSystemBackend.Dto.AccountDTO;
using BankSystemBackend.Dto.CustomerDTO;
using BankSystemBackend.Dto.LoanDTO;

namespace BankSystemBackend.IRepository
{
    public interface ITellerRepo
    {
        // --- Transactions ---------------------------------------------
        Task<TransactionResponseDto> DepositAsync(
            int accountId, decimal amount, string message = "");

        Task<TransactionResponseDto> WithdrawAsync(
            int accountId, decimal amount, string message = "");

        Task<TransactionResponseDto> TransferAsync(TransactionDto dto);

        Task<List<TransactionResponseDto>> GetTransactionHistoryAsync(int accountId, int page = 1, int pageSize = 10);

        Task<TransactionResponseDto?> GetTransactionByIdAsync(int transactionId);

        // --- Accounts -------------------------------------------------
        Task<DisplayAccount?> GetAccountByIdAsync(int accountId);

        Task<List<DisplayAccount>> GetCustomerAccountsAsync(string customerId, int page = 1, int pageSize = 10);

        Task<decimal> GetAccountBalanceAsync(int accountId);

        // --- Customer & Loans  -----------------------------
        Task<DisplayLoans> AddLoansAsync(string customerId, AddLoan dto);
        Task<DisplayCustomer?> GetCustomerByIdAsync(string customerId);

        Task<List<DisplayLoans>> GetCustomerLoansAsync(string customerId);
    }
}


