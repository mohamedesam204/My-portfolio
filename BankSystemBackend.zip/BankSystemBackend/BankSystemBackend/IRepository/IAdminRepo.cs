using BankSystemBackend.Dto.BranchDto;
using BankSystemBackend.Dto.CustomerDTO;
using BankSystemBackend.Dto.TellerDTO;

namespace BankSystemBackend.IRepository
{
    public interface IAdminRepo
    {
        // --- Customer reads -------------------------------------------
        Task<List<DisplayCustomer>> GetAllCustomersAsync(int page = 1, int pageSize = 10);
        Task<DisplayCustomer?> GetCustomerByIdAsync(string id);
        Task<int> GetCustomerCountAsync();

        // --- Customer write -------------------------------------------
        Task<BankSystemBackend.Dto.AccountDTO.DisplayAccount> AddAccountAsync(string customerId, BankSystemBackend.Dto.AccountDTO.CreateAccount dto);
        Task<DisplayCustomer> AddCustomerAsync(AddCustomer customer);
        Task<DisplayCustomer> UpdateCustomerAsync(string id, EditCustomer dto);
        Task<bool> DeleteCustomerAsync(string id);

        // --- Aggregate statistics -------------------------------------
        Task<decimal> GetTotalDepositsAsync();
        Task<decimal> GetTotalLoansAsync();
        Task<decimal> TotalAmountAsync();
        Task<decimal> GetTotalFeesAsync();
        Task<decimal> TotalWithdrawalsAsync();

        // --- Teller CRUD ----------------------------------------------
        Task<DisplayTeller?> GetTellerByIdAsync(string id);
        Task<List<DisplayTeller>> GetAllTellersAsync(int page = 1, int pageSize = 10);
        Task<int> GetTellerCountAsync();
        Task<DisplayTeller> AddTellerAsync(AddTeller teller);
        Task<DisplayTeller> UpdateTellerAsync(string id, EditTeller teller);
        Task<bool> DeleteTellerAsync(string id);

        // --- Branch CRUD ----------------------------------------------
        Task<DisplayBranch> AddBranchAsync(AddBranch branch);
        Task<DisplayBranch> UpdateBranchAsync(int id, EditBranch branch);
        Task<bool> DeleteBranchAsync(int id);
        Task<List<DisplayBranch>> GetAllBranchesAsync();
        Task<DisplayBranch?> GetBranchByIdAsync(int id);
        Task<int> GetBranchCountAsync();
    }
}


